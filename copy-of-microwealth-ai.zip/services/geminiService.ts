import { GoogleGenAI, Type } from "@google/genai";
import { PortfolioFormData, Portfolio } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const portfolioSchema = {
  type: Type.OBJECT,
  properties: {
    portfolio_name: { type: Type.STRING },
    allocations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          symbol: { type: Type.STRING },
          weight: { type: Type.STRING },
        },
        required: ['symbol', 'weight'],
      },
    },
    rationale: { type: Type.STRING },
    rebalance_frequency: { type: Type.STRING },
    disclaimer: { type: Type.STRING },
  },
  required: ['portfolio_name', 'allocations', 'rationale', 'rebalance_frequency', 'disclaimer'],
};

const parseJsonFromResponse = (text: string): any => {
    let jsonText = text.trim();
    
    if (jsonText.startsWith('```json')) {
      jsonText = jsonText.slice(7, -3).trim();
    } else if (jsonText.startsWith('```')) {
      jsonText = jsonText.slice(3, -3).trim();
    }

    const startIndex = jsonText.indexOf('{');
    const endIndex = jsonText.lastIndexOf('}');

    if (startIndex === -1 || endIndex === -1 || endIndex < startIndex) {
      console.error("Invalid JSON response from AI:", text);
      throw new Error("AI response did not contain a valid JSON object.");
    }
    
    jsonText = jsonText.substring(startIndex, endIndex + 1);
    return JSON.parse(jsonText);
}

export const generatePortfolio = async (formData: PortfolioFormData): Promise<Portfolio> => {
  const prompt = `
    You are MicroWealth AI, an expert financial educator specializing in creating diversified ETF portfolios for beginners.
    Based on the user's profile below, generate a sample portfolio.

    User Profile:
    - Investment Goal: ${formData.goal}
    - Time Horizon: ${formData.timeHorizon} years
    - Risk Tolerance: ${formData.riskTolerance}
    - Monthly Contribution: $${formData.monthlyContribution}

    Your Task:
    1. Create a portfolio of 3 to 5 diversified, low-cost ETFs.
    2. The total allocation weight must equal 100%. Ensure weights are formatted as strings with a percentage sign (e.g., "40%").
    3. The 'rationale' should be a plain-English explanation of why this portfolio is suitable for the user, referencing their specific inputs (e.g., "Because your time horizon is long and risk tolerance is high...").
    4. The 'rebalance_frequency' should be a simple recommendation (e.g., "Annually", "Semi-Annually").
    5. The 'disclaimer' must be exactly: "Educational tool – not financial advice."

    You MUST respond with a valid JSON object that adheres to the provided schema. Do not include any markdown formatting.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: portfolioSchema,
        temperature: 0.5,
      }
    });

    const portfolioData: Portfolio = parseJsonFromResponse(response.text);
    
    const totalWeight = portfolioData.allocations.reduce((sum, alloc) => {
        return sum + parseFloat(alloc.weight.replace('%', ''));
    }, 0);

    if (Math.round(totalWeight) !== 100) {
        throw new Error(`AI returned allocations that do not sum to 100%. Total: ${totalWeight}%`);
    }

    return portfolioData;
  } catch (error) {
    console.error("Error generating portfolio:", error);
    throw new Error("Failed to generate portfolio from AI. Please check your inputs and try again.");
  }
};

export const getEtfExplanation = async (symbol: string): Promise<string> => {
  const prompt = `
    Provide a brief, one-paragraph explanation for the ETF with the ticker symbol: ${symbol}.
    Focus on what it tracks (e.g., the specific index or market sector) and its primary investment purpose.
    Keep the language simple and clear, as if explaining it to a beginner investor. Do not add any conversational text.
  `;
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    return response.text.trim();
  } catch (error) {
    console.error(`Error fetching explanation for ${symbol}:`, error);
    throw new Error(`Could not fetch an explanation for ${symbol}.`);
  }
};


export const simulateMarketUpdate = async (symbols: string[]): Promise<Record<string, number>> => {
  const marketUpdateSchema = {
    type: Type.OBJECT,
    properties: symbols.reduce((acc, symbol) => {
      acc[symbol] = { type: Type.NUMBER };
      return acc;
    }, {} as Record<string, { type: Type.STRING }>),
    required: symbols,
  };

  const prompt = `
    You are a market data simulator. For the following list of ETF ticker symbols, generate a realistic, small, random percentage price change for each to simulate their performance over one month.

    - The change should be a number (e.g., 1.5 for +1.5%, -0.8 for -0.8%).
    - The changes should be plausible for a typical month in the market. Avoid extreme fluctuations.
    - Symbols: ${symbols.join(', ')}

    You MUST respond with a valid JSON object where keys are the ticker symbols and values are the numeric percentage change. Do not include any markdown formatting.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: marketUpdateSchema,
        temperature: 0.8,
      },
    });
    
    return parseJsonFromResponse(response.text);

  } catch (error) {
    console.error("Error simulating market update:", error);
    throw new Error("Failed to simulate market update from AI.");
  }
};
