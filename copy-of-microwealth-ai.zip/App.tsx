import React, { useState, useCallback } from 'react';
import { Portfolio, PortfolioFormData, RiskTolerance, TrackedPortfolio } from './types';
import { generatePortfolio } from './services/geminiService';
import PortfolioForm from './components/PortfolioForm';
import PortfolioDisplay from './components/PortfolioDisplay';
import PortfolioTracker from './components/PortfolioTracker';
import { LogoIcon, GeneratorIcon, TrackerIcon } from './components/Icons';

type View = 'generator' | 'tracker';

const App: React.FC = () => {
  const [view, setView] = useState<View>('generator');
  const [formData, setFormData] = useState<PortfolioFormData>({
    goal: 'Long-term growth for retirement',
    timeHorizon: 20,
    riskTolerance: RiskTolerance.Medium,
    monthlyContribution: 500,
  });
  const [generatedPortfolio, setGeneratedPortfolio] = useState<Portfolio | null>(null);
  const [trackedPortfolio, setTrackedPortfolio] = useState<TrackedPortfolio | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleFormChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: (name === 'timeHorizon' || name === 'monthlyContribution') ? Number(value) : value,
    }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setGeneratedPortfolio(null);
    try {
      const result = await generatePortfolio(formData);
      setGeneratedPortfolio(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };
  
  const handleStartTracking = (portfolioToTrack: Portfolio, initialInvestment: number) => {
    // Assume a starting price of $100 for each ETF for simulation purposes
    const initialPricePerShare = 100;

    const holdings = portfolioToTrack.allocations.map(alloc => {
      const weight = parseFloat(alloc.weight.replace('%', '')) / 100;
      const investmentAmount = initialInvestment * weight;
      const shares = investmentAmount / initialPricePerShare;
      return {
        symbol: alloc.symbol,
        shares: shares,
        costBasis: investmentAmount,
        currentValue: investmentAmount,
      };
    });

    const newTrackedPortfolio: TrackedPortfolio = {
      name: portfolioToTrack.portfolio_name,
      holdings: holdings,
      transactions: [
        {
          date: new Date().toLocaleDateString(),
          amount: initialInvestment,
          type: 'Initial Investment',
        },
      ],
      valueHistory: [{ month: 0, value: initialInvestment }],
    };
    
    setTrackedPortfolio(newTrackedPortfolio);
    setView('tracker');
  };

  return (
    <div className="bg-slate-900 min-h-screen font-sans text-slate-200 p-4 sm:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="mb-10">
          <div className="flex items-center justify-center gap-3 mb-4">
            <LogoIcon className="h-10 w-10 text-emerald-400" />
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-sky-400 to-emerald-400 text-transparent bg-clip-text">
              MicroWealth AI
            </h1>
          </div>
          <p className="text-lg text-slate-400 max-w-2xl mx-auto text-center">
            Learn how to invest smarter with AI-powered portfolio education.
          </p>
        </header>

        <nav className="flex justify-center mb-8">
          <div className="bg-slate-800/50 border border-slate-700 rounded-lg p-1 flex space-x-1">
            <NavButton title="Generator" icon={<GeneratorIcon />} isActive={view === 'generator'} onClick={() => setView('generator')} />
            <NavButton title="Tracker" icon={<TrackerIcon />} isActive={view === 'tracker'} onClick={() => setView('tracker')} isDisabled={!trackedPortfolio} />
          </div>
        </nav>

        <main>
          {view === 'generator' && (
            <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
              <div className="lg:col-span-2">
                <PortfolioForm
                  formData={formData}
                  onFormChange={handleFormChange}
                  onSubmit={handleSubmit}
                  loading={loading}
                />
              </div>
              <div className="lg:col-span-3">
                <PortfolioDisplay
                  portfolio={generatedPortfolio}
                  loading={loading}
                  error={error}
                  onStartTracking={(p) => handleStartTracking(p, formData.monthlyContribution)}
                />
              </div>
            </div>
          )}
          {view === 'tracker' && trackedPortfolio && (
             <PortfolioTracker 
              portfolio={trackedPortfolio}
              onPortfolioUpdate={setTrackedPortfolio}
            />
          )}
        </main>

        <footer className="text-center mt-12 text-slate-500 text-sm">
          <p>&copy; {new Date().getFullYear()} MicroWealth AI. All Rights Reserved.</p>
        </footer>
      </div>
    </div>
  );
};

interface NavButtonProps {
  title: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
  isDisabled?: boolean;
}

const NavButton: React.FC<NavButtonProps> = ({ title, icon, isActive, onClick, isDisabled }) => (
  <button
    onClick={onClick}
    disabled={isDisabled}
    title={isDisabled ? 'Please generate a portfolio first.' : title}
    className={`px-4 py-2 text-sm font-medium rounded-md flex items-center gap-2 transition-colors duration-200 ${
      isActive
        ? 'bg-emerald-500 text-white'
        : 'text-slate-300 hover:bg-slate-700/50'
    } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
  >
    {icon}
    {title}
  </button>
);


export default App;