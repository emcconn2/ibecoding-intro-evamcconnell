import React, { useState, useEffect } from 'react';
import { Portfolio } from '../types';
import { getEtfExplanation } from '../services/geminiService';
import { RationaleIcon, RebalanceIcon, DisclaimerIcon, ChartIcon, InfoIcon, LoadingSpinnerIcon, CloseIcon, TrackerIcon } from './Icons';

interface PortfolioDisplayProps {
  portfolio: Portfolio | null;
  loading: boolean;
  error: string | null;
  onStartTracking: (portfolio: Portfolio) => void;
}

const COLORS = ['#10b981', '#38bdf8', '#818cf8', '#f472b6', '#fb923c'];

const PortfolioDisplay: React.FC<PortfolioDisplayProps> = ({ portfolio, loading, error, onStartTracking }) => {
  const [selectedEtf, setSelectedEtf] = useState<{ symbol: string; explanation: string; error?: string | null; isLoading: boolean } | null>(null);
  const [isRechartsReady, setIsRechartsReady] = useState(false);

  useEffect(() => {
    if ((window as any).Recharts) {
      setIsRechartsReady(true);
    } else {
      // Poll for the library in case it loads asynchronously
      const interval = setInterval(() => {
        if ((window as any).Recharts) {
          setIsRechartsReady(true);
          clearInterval(interval);
        }
      }, 100);
      return () => clearInterval(interval);
    }
  }, []);

  const handleSymbolClick = async (symbol: string) => {
    setSelectedEtf({ symbol, explanation: '', isLoading: true });
    try {
      const explanationText = await getEtfExplanation(symbol);
      setSelectedEtf({ symbol, explanation: explanationText, isLoading: false });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'An unexpected error occurred.';
      setSelectedEtf({ symbol, explanation: '', error: errorMessage, isLoading: false });
    }
  };

  const handleCloseModal = () => {
    setSelectedEtf(null);
  };
  
  if (loading) {
    return (
      <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg flex items-center justify-center h-full min-h-[400px]">
        <div className="text-center">
          <div className="animate-pulse text-emerald-400 text-2xl font-semibold">Analyzing your profile...</div>
          <p className="text-slate-400 mt-2">Our AI is crafting your educational portfolio.</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-900/20 backdrop-blur-sm p-6 rounded-xl border border-red-500/50 shadow-lg flex flex-col items-center justify-center h-full min-h-[400px]">
        <DisclaimerIcon className="h-12 w-12 text-red-400 mb-4" />
        <h3 className="text-xl font-semibold text-red-300">An Error Occurred</h3>
        <p className="text-red-400 mt-2 text-center">{error}</p>
      </div>
    );
  }

  if (!portfolio) {
    return (
      <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg flex flex-col items-center justify-center h-full min-h-[400px] text-center">
        <InfoIcon className="h-12 w-12 text-sky-400 mb-4" />
        <h3 className="text-xl font-semibold text-slate-200">Your Portfolio Awaits</h3>
        <p className="text-slate-400 mt-2 max-w-sm">
          Fill out the form on the left to generate a personalized educational portfolio suggestion.
        </p>
      </div>
    );
  }
  
  const { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } = (window as any).Recharts || {};

  const chartData = portfolio.allocations.map(a => ({
    name: a.symbol,
    value: parseFloat(a.weight.replace('%', ''))
  }));

  return (
    <>
      <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg space-y-8">
        <div>
          <h2 className="text-3xl font-bold text-center text-white">{portfolio.portfolio_name}</h2>
          <div className="mt-4 flex justify-center">
             <button 
                onClick={() => onStartTracking(portfolio)}
                className="flex items-center gap-2 bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-md transition-all duration-300 transform hover:scale-105"
             >
                <TrackerIcon />
                Start Tracking this Portfolio
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="h-64">
            {isRechartsReady ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {chartData.map((_entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value: number) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-slate-400">
                <LoadingSpinnerIcon className="h-8 w-8 text-emerald-400" />
              </div>
            )}
          </div>
          
          <div className="bg-slate-900/50 p-4 rounded-lg border border-slate-700">
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2"><ChartIcon /> Allocations</h3>
            <ul className="space-y-1">
              {portfolio.allocations.map((alloc, index) => (
                <li key={alloc.symbol} className="flex justify-between items-center text-slate-300">
                  <span className="flex items-center gap-2">
                    <span className="h-3 w-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                    {alloc.symbol}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white">{alloc.weight}</span>
                    <button onClick={() => handleSymbolClick(alloc.symbol)} className="text-slate-400 hover:text-sky-400 transition-colors">
                      <InfoIcon className="h-5 w-5" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
        
        <div className="space-y-6">
          <InfoCard title="Rationale" icon={<RationaleIcon />}>
            {portfolio.rationale}
          </InfoCard>
          <InfoCard title="Rebalancing Frequency" icon={<RebalanceIcon />}>
            {portfolio.rebalance_frequency}
          </InfoCard>
          <InfoCard title="Disclaimer" icon={<DisclaimerIcon />} isDisclaimer={true}>
            {portfolio.disclaimer}
          </InfoCard>
        </div>
      </div>
      {selectedEtf && <EtfExplanationModal etf={selectedEtf} onClose={handleCloseModal} />}
    </>
  );
};

const InfoCard: React.FC<{ title: string; icon: React.ReactNode; children: React.ReactNode; isDisclaimer?: boolean }> = ({ title, icon, children, isDisclaimer }) => (
  <div className={isDisclaimer ? 'p-4 rounded-lg border bg-amber-900/20 border-amber-500/30' : 'p-4 rounded-lg bg-slate-900/50 border border-slate-700/50'}>
    <h3 className={`text-lg font-semibold mb-2 flex items-center gap-2 ${isDisclaimer ? 'text-amber-300' : 'text-sky-300'}`}>
      {icon}
      {title}
    </h3>
    <p className={`${isDisclaimer ? 'text-amber-300/90' : 'text-slate-300'}`}>{children}</p>
  </div>
);

const EtfExplanationModal: React.FC<{ etf: { symbol: string; explanation: string; error?: string | null; isLoading: boolean }; onClose: () => void; }> = ({ etf, onClose }) => {
  return (
    <div 
      className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
      aria-modal="true"
      role="dialog"
    >
      <div 
        className="bg-slate-800 border border-slate-700 rounded-xl shadow-2xl w-full max-w-lg p-6 relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button 
          onClick={onClose} 
          className="absolute top-3 right-3 text-slate-400 hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <CloseIcon className="h-6 w-6" />
        </button>
        <h3 className="text-2xl font-bold text-white mb-4">What is {etf.symbol}?</h3>
        {etf.isLoading && (
          <div className="flex items-center justify-center h-24">
            <LoadingSpinnerIcon className="text-emerald-400 h-8 w-8" />
          </div>
        )}
        {etf.error && (
          <p className="text-red-400">{etf.error}</p>
        )}
        {!etf.isLoading && !etf.error && (
          <p className="text-slate-300 leading-relaxed">{etf.explanation}</p>
        )}
      </div>
    </div>
  );
};

export default PortfolioDisplay;