
import React from 'react';
import { PortfolioFormData, RiskTolerance } from '../types';
import { LoadingSpinnerIcon } from './Icons';

interface PortfolioFormProps {
  formData: PortfolioFormData;
  onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading: boolean;
}

const PortfolioForm: React.FC<PortfolioFormProps> = ({ formData, onFormChange, onSubmit, loading }) => {
  return (
    <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg h-full">
      <h2 className="text-2xl font-semibold text-white mb-6">Your Profile</h2>
      <form onSubmit={onSubmit} className="space-y-6">
        <div>
          <label htmlFor="goal" className="block text-sm font-medium text-slate-300 mb-1">
            Investment Goal
          </label>
          <input
            type="text"
            id="goal"
            name="goal"
            value={formData.goal}
            onChange={onFormChange}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white placeholder-slate-400 focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition"
            placeholder="e.g., Retirement, House Down Payment"
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="timeHorizon" className="block text-sm font-medium text-slate-300 mb-1">
              Time Horizon (Years)
            </label>
            <input
              type="number"
              id="timeHorizon"
              name="timeHorizon"
              value={formData.timeHorizon}
              onChange={onFormChange}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition"
              min="1"
              max="50"
              required
            />
          </div>
          <div>
            <label htmlFor="monthlyContribution" className="block text-sm font-medium text-slate-300 mb-1">
              Monthly Contribution ($)
            </label>
            <input
              type="number"
              id="monthlyContribution"
              name="monthlyContribution"
              value={formData.monthlyContribution}
              onChange={onFormChange}
              className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition"
              min="0"
              step="50"
              required
            />
          </div>
        </div>

        <div>
          <label htmlFor="riskTolerance" className="block text-sm font-medium text-slate-300 mb-1">
            Risk Tolerance
          </label>
          <select
            id="riskTolerance"
            name="riskTolerance"
            value={formData.riskTolerance}
            onChange={onFormChange}
            className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 px-3 text-white focus:ring-2 focus:ring-emerald-400 focus:border-emerald-400 transition"
            required
          >
            {Object.values(RiskTolerance).map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full flex justify-center items-center gap-2 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-800 disabled:text-slate-400 text-white font-bold py-3 px-4 rounded-md transition-all duration-300 transform hover:scale-105 disabled:scale-100"
        >
          {loading ? (
            <>
              <LoadingSpinnerIcon />
              Generating...
            </>
          ) : (
            'Generate Portfolio'
          )}
        </button>
      </form>
    </div>
  );
};

export default PortfolioForm;
