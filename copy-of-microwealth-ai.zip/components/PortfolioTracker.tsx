import React, { useState, useMemo, useEffect } from 'react';
import { TrackedPortfolio, TrackedHolding } from '../types';
import { simulateMarketUpdate } from '../services/geminiService';
import { LoadingSpinnerIcon, ArrowUpIcon, ArrowDownIcon, PlusIcon, HistoryIcon } from './Icons';

interface PortfolioTrackerProps {
  portfolio: TrackedPortfolio;
  onPortfolioUpdate: (portfolio: TrackedPortfolio) => void;
}

const PortfolioTracker: React.FC<PortfolioTrackerProps> = ({ portfolio, onPortfolioUpdate }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [contributionAmount, setContributionAmount] = useState<number>(100);
  const [isRechartsReady, setIsRechartsReady] = useState(false);

  useEffect(() => {
    if ((window as any).Recharts) {
      setIsRechartsReady(true);
    } else {
      const interval = setInterval(() => {
        if ((window as any).Recharts) {
          setIsRechartsReady(true);
          clearInterval(interval);
        }
      }, 100);
      return () => clearInterval(interval);
    }
  }, []);

  const stats = useMemo(() => {
    const totalValue = portfolio.holdings.reduce((sum, h) => sum + h.currentValue, 0);
    const totalInvested = portfolio.transactions.reduce((sum, t) => sum + t.amount, 0);
    const totalPandL = totalValue - totalInvested;
    const totalPandLPercent = totalInvested > 0 ? (totalPandL / totalInvested) * 100 : 0;
    return { totalValue, totalInvested, totalPandL, totalPandLPercent };
  }, [portfolio]);
  
  const handleMarketUpdate = async () => {
    setLoading(true);
    setError(null);
    try {
      const symbols = portfolio.holdings.map(h => h.symbol);
      const changes = await simulateMarketUpdate(symbols);
      
      let newTotalValue = 0;
      const updatedHoldings = portfolio.holdings.map(holding => {
        const changePercent = changes[holding.symbol] || 0;
        const updatedValue = holding.currentValue * (1 + changePercent / 100);
        newTotalValue += updatedValue;
        return { ...holding, currentValue: updatedValue };
      });
      
      const newHistoryEntry = {
        month: portfolio.valueHistory.length,
        value: newTotalValue,
      };

      onPortfolioUpdate({ 
        ...portfolio, 
        holdings: updatedHoldings,
        valueHistory: [...portfolio.valueHistory, newHistoryEntry]
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update market data.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddContribution = (e: React.FormEvent) => {
    e.preventDefault();
    if (contributionAmount <= 0) return;

    const totalValueBefore = stats.totalValue;
    // Handle case where total value is zero to avoid division by zero
    const isFirstContributionToEmpty = totalValueBefore === 0;
    
    const newHoldings = portfolio.holdings.map(holding => {
        // If it's the first contribution, we can't use value proportion.
        // Instead, we should use the original portfolio allocation weights.
        // This is a simplification; a real app would need a more robust allocation strategy.
        // For this educational tool, we'll assume an even split for now if value is zero.
        const proportion = isFirstContributionToEmpty 
            ? 1 / portfolio.holdings.length
            : holding.currentValue / totalValueBefore;
            
        const contributionForHolding = contributionAmount * proportion;
        // If shares are 0, we can't calculate price. Assume a price, e.g., $100 for simplicity.
        const currentPricePerShare = holding.shares > 0 ? holding.currentValue / holding.shares : 100;
        const newShares = contributionForHolding / currentPricePerShare;
        
        return {
            ...holding,
            shares: holding.shares + newShares,
            costBasis: holding.costBasis + contributionForHolding,
            currentValue: holding.currentValue + contributionForHolding,
        };
    });

    const newTransaction = {
        date: new Date().toLocaleDateString(),
        amount: contributionAmount,
        type: 'Contribution' as const,
    };

    onPortfolioUpdate({
        ...portfolio,
        holdings: newHoldings,
        transactions: [...portfolio.transactions, newTransaction],
    });

    setContributionAmount(100);
  }
  
  const { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } = (window as any).Recharts || {};

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold text-center text-white">{portfolio.name} - Tracker</h2>
      
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Total Value" value={stats.totalValue.toFixed(2)} prefix="$" />
        <StatCard title="Total Invested" value={stats.totalInvested.toFixed(2)} prefix="$" />
        <StatCard title="Total P/L" value={stats.totalPandL.toFixed(2)} prefix="$" suffix={`(${stats.totalPandLPercent.toFixed(2)}%)`} isPL={true} plValue={stats.totalPandL} />
      </div>
      
      {/* Performance Chart */}
      <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg">
        <h3 className="text-xl font-semibold mb-4 text-white flex items-center gap-2"><HistoryIcon /> Performance History</h3>
        <div className="h-64">
          {isRechartsReady ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={portfolio.valueHistory} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                 <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="month" tickFormatter={(tick) => `M${tick}`} stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" tickFormatter={(tick) => `$${tick.toLocaleString()}`} />
                <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
                <Tooltip 
                    contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', color: '#cbd5e1' }}
                    labelFormatter={(label) => `Month ${label}`}
                    formatter={(value: number) => [value.toLocaleString('en-US', { style: 'currency', currency: 'USD' }), 'Portfolio Value']}
                />
                <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorValue)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-400">
              <LoadingSpinnerIcon />
            </div>
          )}
        </div>
      </div>


      {/* Holdings Table */}
      <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg">
        <h3 className="text-xl font-semibold mb-4 text-white">Your Holdings</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-600 text-sm text-slate-400">
                <th className="p-2">Symbol</th>
                <th className="p-2 text-right">Current Value</th>
                <th className="p-2 text-right">Cost Basis</th>
                <th className="p-2 text-right">P/L</th>
              </tr>
            </thead>
            <tbody>
              {portfolio.holdings.map(h => <HoldingRow key={h.symbol} holding={h} />)}
            </tbody>
          </table>
        </div>
      </div>

      {/* Actions and Transactions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg space-y-6">
          <h3 className="text-xl font-semibold text-white">Tracker Controls</h3>
          <div>
            <p className="text-sm text-slate-400 mb-2">Click to advance the simulation by one month and see how the market affects your portfolio's value.</p>
            <button
              onClick={handleMarketUpdate}
              disabled={loading}
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-4 rounded-md transition-colors disabled:bg-emerald-800 disabled:text-slate-400 flex items-center justify-center gap-2"
            >
              {loading ? <><LoadingSpinnerIcon /> Simulating...</> : 'Simulate Next Month'}
            </button>
            {error && <p className="text-red-400 text-sm mt-2 text-center">{error}</p>}
          </div>

          <div className="border-t border-slate-700"></div>

          <div>
            <h4 className="font-semibold text-white mb-2">Add a Contribution</h4>
            <p className="text-sm text-slate-400 mb-3">Simulate adding more funds to your investment.</p>
            <form onSubmit={handleAddContribution} className="flex items-center gap-2">
              <div className="relative flex-grow">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">$</span>
                  <input
                    type="number"
                    value={contributionAmount}
                    onChange={(e) => setContributionAmount(Number(e.target.value))}
                    className="w-full bg-slate-700/50 border border-slate-600 rounded-md py-2 pl-6 pr-3 text-white focus:ring-2 focus:ring-sky-400 transition"
                    min="1"
                    step="10"
                    aria-label="Contribution Amount"
                  />
              </div>
              <button type="submit" className="flex-shrink-0 bg-sky-500 hover:bg-sky-600 text-white font-bold py-2 px-4 rounded-md transition-colors flex items-center gap-2">
                <PlusIcon />
                <span>Add</span>
              </button>
            </form>
          </div>
        </div>

        <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl border border-slate-700 shadow-lg">
          <h3 className="text-xl font-semibold mb-4 text-white">Transaction History</h3>
          <ul className="space-y-2 max-h-48 overflow-y-auto">
            {portfolio.transactions.slice().reverse().map((t, i) => (
              <li key={i} className="flex justify-between items-center text-sm bg-slate-900/50 p-2 rounded-md">
                <span className="text-slate-400">{t.date} - {t.type}</span>
                <span className="font-semibold text-slate-200">${t.amount.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

const HoldingRow: React.FC<{holding: TrackedHolding}> = ({ holding }) => {
  const pandl = holding.currentValue - holding.costBasis;
  const pandlPercent = holding.costBasis > 0 ? (pandl / holding.costBasis) * 100 : 0;
  const isGain = pandl >= 0;

  return (
    <tr className="border-b border-slate-700 last:border-0">
      <td className="p-2 font-semibold">{holding.symbol}</td>
      <td className="p-2 text-right">${holding.currentValue.toFixed(2)}</td>
      <td className="p-2 text-right text-slate-400">${holding.costBasis.toFixed(2)}</td>
      <td className={`p-2 text-right font-semibold flex items-center justify-end gap-1 ${isGain ? 'text-emerald-400' : 'text-red-400'}`}>
        {isGain ? <ArrowUpIcon/> : <ArrowDownIcon/>}
        {pandl.toFixed(2)} ({pandlPercent.toFixed(2)}%)
      </td>
    </tr>
  );
};

const StatCard: React.FC<{title: string, value: string, prefix?: string, suffix?: string, isPL?: boolean, plValue?: number}> = ({ title, value, prefix, suffix, isPL, plValue = 0 }) => {
  const plColor = plValue >= 0 ? 'text-emerald-400' : 'text-red-400';
  return (
    <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700">
      <h4 className="text-sm text-slate-400 font-medium">{title}</h4>
      <p className={`text-2xl font-bold ${isPL ? plColor : 'text-white'}`}>
        {prefix}{value}{suffix}
      </p>
    </div>
  )
};

export default PortfolioTracker;