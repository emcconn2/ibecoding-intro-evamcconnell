export enum RiskTolerance {
  Low = 'Low',
  Medium = 'Medium',
  High = 'High',
}

export interface PortfolioFormData {
  goal: string;
  timeHorizon: number;
  riskTolerance: RiskTolerance;
  monthlyContribution: number;
}

export interface Allocation {
  symbol: string;
  weight: string;
}

export interface Portfolio {
  portfolio_name: string;
  allocations: Allocation[];
  rationale: string;
  rebalance_frequency: string;
  disclaimer: string;
}

// Types for the new Portfolio Tracker feature
export interface Transaction {
  date: string;
  amount: number;
  type: 'Initial Investment' | 'Contribution';
}

export interface TrackedHolding {
  symbol: string;
  shares: number;
  costBasis: number;
  currentValue: number;
}

export interface TrackedPortfolio {
  name: string;
  holdings: TrackedHolding[];
  transactions: Transaction[];
  valueHistory: { month: number; value: number }[];
}